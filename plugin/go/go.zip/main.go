package main

import (
    "context"
    "fmt"
    "os"
    "os/signal"
    "syscall"

    "github.com/canopy-network/go-plugin/contract"
)

func main() {
    fmt.Println("Starting plugin...")

    contract.StartPlugin(contract.DefaultConfig())

    fmt.Println("Plugin started")

    ctx, stop := signal.NotifyContext(
        context.Background(),
        os.Interrupt,
        syscall.SIGTERM,
    )
    defer stop()

    <-ctx.Done()
}